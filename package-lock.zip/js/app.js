/**
 * PROFLIC — PRECISION INDUSTRIAL METROLOGY & QUALITY ENGINEERING
 * Multi-Page Luxury Vanilla JavaScript Client Application
 * Brand: Proflic (PROFLIC Technologies) • Chhatrapati Sambhajinagar, Maharashtra
 * Real Info Source: https://www.proflic.in/
 * Telephone: +91 84597 06344 • Email: proflic.tech@gmail.com
 */

(function () {
  "use strict";

  // --- 1. Real Technical Service Specifications Dataset ---
  const servicesSpecs = {
    cmm: {
      title: "Bridge Coordinate Measuring Machine (CMM) Inspection",
      eyebrow: "Sub-Micron Dimensional Inspection",
      overview: "High-precision automated bridge CMM coordinate dimensional measurement for precision machined components, automotive engine cylinder blocks, transmission casings, and aerospace blisks. Certified measurement down to < 0.001 mm micrometric accuracy.",
      specs: [
        { label: "Volumetric Accuracy", value: "E0,MPE = 1.5 + L/350 µm (< 0.001 mm)" },
        { label: "Probing Repeatability", value: "0.8 µm Probing Uncertainty" },
        { label: "Software Platforms", value: "Zeiss CALYPSO • PC-DMIS CAD++" },
        { label: "GD&T Verification", value: "ASME Y14.5-2018 (True Position, Profile, Runout)" },
        { label: "Inspection Environment", value: "Temperature-Controlled Metrology Laboratory (20°C ± 0.5°C)" },
        { label: "Traceability", value: "NABL & NIST Calibrated Length Masters" }
      ],
      deliverables: [
        "Certified AS9102 Form 3 / PPAP Level 3 Quality Dossiers",
        "Full GD&T Feature Control Frame Evaluation",
        "CAD-to-Part Deviation Spreadsheets & Color Deviation Plots",
        "Independent Third-Party Quality Inspection Certificate"
      ]
    },
    portable: {
      title: "On-Site Portable CMM Inspection (Articulated Arm)",
      eyebrow: "24/7 Mobile Dispatch Across Maharashtra",
      overview: "Portable multi-axis articulated CMM arms deployed directly to your CNC machine shop floor, toolroom, or fabrication bay across Chhatrapati Sambhajinagar, Aurangabad, Waluj, Pune, and Maharashtra. Enables in-situ dimensional inspection on machine beds before unclamping, eliminating transit risks.",
      specs: [
        { label: "Arm Architecture", value: "7-Axis High-Accuracy Articulated Measuring Arm" },
        { label: "Tactile Probes", value: "Hard Probe & High-Sensitivity Touch-Trigger Styli" },
        { label: "Inspection Mode", value: "In-situ on CNC bedplates, welding fixtures, large frames" },
        { label: "Service Radius", value: "Waluj, Shendra, Chikalthana, Pune, Nashik, Maharashtra" },
        { label: "Availability", value: "24/7 Rapid Emergency Mobile Dispatch" },
        { label: "Turnaround", value: "Immediate On-Floor Real-Time Report Generation" }
      ],
      deliverables: [
        "Instant CNC Bedplate Dimensional Verification",
        "Fixture Qualification & Assembly Alignment Reports",
        "Bubble Drawing Inspection Data Sheets",
        "Immediate Go / No-Go Machining Sign-Off"
      ]
    },
    laser: {
      title: "3D Blue Laser Scanning & Optical Inspection",
      eyebrow: "2,000,000 Points / Sec Non-Contact Capture",
      overview: "High-density blue laser line 3D optical scanning synchronized with tactile touch probing. Ideal for organic contoured surfaces, automotive sheet metal stamping dies, injection mold cavities, and aerospace turbine blades.",
      specs: [
        { label: "Data Capture Speed", value: "2,000,000 measurements / second" },
        { label: "Optical Resolution", value: "Down to 0.020 mm point spacing" },
        { label: "Surface Flexibility", value: "Inspects dark, reflective, and machined surfaces" },
        { label: "Platform Software", value: "PolyWorks|Inspector™ • GOM Inspect Pro" },
        { label: "Inspection Protocol", value: "VDI/VDE 2634 Part 2/3 Optical Metrology Standards" },
        { label: "Output Files", value: "Cleaned Polygonal STL, OBJ, Raw Point Clouds (.pts, .asc)" }
      ],
      deliverables: [
        "Full 3D Surface Deviation Color Maps (CAD vs Actual)",
        "Wall-Thickness & Cross-Sectional Gap / Flush Analysis",
        "High-Resolution Triangular STL Mesh for Toolmaking",
        "First-Article Optical Inspection Dossier"
      ]
    },
    reverse: {
      title: "Scan-to-CAD Reverse Engineering & Surface Modeling",
      eyebrow: "Parametric 3D CAD Reconstruction",
      overview: "Transforming raw physical scan data and point clouds into high-integrity, fully parametric CAD solid models. Perfect for reproducing legacy dies, worn tooling, aerospace blades, aftermarket components, or parts with missing 2D/3D engineering drawings.",
      specs: [
        { label: "CAD Platforms", value: "SolidWorks • Siemens NX • CATIA V5" },
        { label: "Surface Fidelity", value: "Class-A Continuous NURBS Surfaces" },
        { label: "Deliverable Formats", value: "STEP AP242 / AP214, IGES 5.3, Parasolid (.x_t)" },
        { label: "Parametric History", value: "Fully constrained native sketches & editable feature trees" },
        { label: "Tool Wear Compensation", value: "Springback restoration & nominal geometry healing" },
        { label: "Drafting", value: "2D Manufacturing Blueprints with ASME Y14.5 GD&T" }
      ],
      deliverables: [
        "Fully Editable Native Parametric Solid Models (SolidWorks / NX)",
        "Universal Neutral STEP & IGES 3D CAD Files",
        "Manufacturing 2D Prints with GD&T Datum Framework",
        "Deviation Analysis Report (Reconstructed CAD vs Scan Mesh)"
      ]
    },
    programming: {
      title: "Offline CMM Programming Support & Scripting",
      eyebrow: "PC-DMIS CAD++ & PolyWorks|Inspector™",
      overview: "Turnkey DCC offline CMM programming, probe angle indexing (Renishaw PH10/PH20), and collision-free clearance path simulation reducing part measurement cycle times by up to 40%.",
      specs: [
        { label: "Supported Platforms", value: "PC-DMIS CAD++, PolyWorks|Inspector™, Zeiss CALYPSO" },
        { label: "Probe Heads", value: "Motorized indexing (PH10M, PH10MQ, PH20 5-axis)" },
        { label: "Alignment Logic", value: "Iterative, 3-2-1, and Best-Fit CAD Datum Alignments" },
        { label: "Optimization", value: "Automated loop routines & Excel quality report scripting" },
        { label: "Cycle Time Reduction", value: "Up to 40% faster inspection runtimes" },
        { label: "Simulation", value: "Full 3D CAD probe clearance & collision avoidance" }
      ],
      deliverables: [
        "Production-Ready DCC Inspection Script (.prg)",
        "Collision-Free Probe Path 3D Simulation Video / Log",
        "Operator Setup Sheet with Stylus Cluster Layout",
        "Automated Excel / PDF Inspection Output Template"
      ]
    },
    quality: {
      title: "Quality Assurance & FAIR / PPAP Documentation",
      eyebrow: "AS9102 Rev B & AIAG PPAP Level 3",
      overview: "Comprehensive third-party dimensional inspection documentation delivering Aerospace First Article Inspection Reports (FAIR AS9102), Automotive PPAP Level 3 packages, and Gauge R&R (Measurement Systems Analysis).",
      specs: [
        { label: "Aerospace Standard", value: "SAE AS9102 Rev B (Forms 1, 2, and 3)" },
        { label: "Automotive Standard", value: "AIAG PPAP Level 3 Dimensional Results" },
        { label: "Traceability", value: "100% NABL / NIST Traceable Certification" },
        { label: "Statistical Tools", value: "Cp, Cpk, Pp, Ppk Capability Calculations" },
        { label: "MSA Analysis", value: "Gauge R&R (Repeatability & Reproducibility Studies)" },
        { label: "Sign-Off", value: "Independent Senior Metrologist Approval Stamp" }
      ],
      deliverables: [
        "Ballooned 2D Engineering Prints (.pdf)",
        "Certified AS9102 Forms 1, 2 & 3 or PPAP Documentation",
        "Raw CMM Probe Point Logs & Statistical Summary",
        "Official Certificate of Inspection Conformity"
      ]
    }
  };

  // --- 2. Redesigned App Bar Scroll & Mobile Drawer ---
  function initHeader() {
    const header = document.querySelector(".nav-dock-capsule, .header-island, .site-header, #siteHeader");
    if (header) {
      window.addEventListener("scroll", () => {
        if (window.scrollY > 15) {
          header.classList.add("scrolled");
        } else {
          header.classList.remove("scrolled");
        }
      }, { passive: true });
    }

    const toggleBtn = document.querySelector(".dock-mobile-toggle, .mobile-toggle, .mobile-menu-toggle");
    const drawer = document.querySelector(".dock-mobile-drawer, .mobile-drawer-island, .mobile-drawer, #mobileDrawer");
    if (toggleBtn && drawer) {
      toggleBtn.addEventListener("click", () => {
        const isOpen = drawer.classList.toggle("open");
        toggleBtn.setAttribute("aria-expanded", isOpen ? "true" : "false");
        toggleBtn.innerHTML = isOpen ? "✕" : "☰";
      });

      // Close drawer on link click
      drawer.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", () => {
          drawer.classList.remove("open");
          if (toggleBtn) {
            toggleBtn.setAttribute("aria-expanded", "false");
            toggleBtn.innerHTML = "☰";
          }
        });
      });
    }

    // Mark current active link
    const currentPath = window.location.pathname.replace(/\/$/, "") || "/";
    document.querySelectorAll(".dock-item, .island-link, .nav-link, .dock-mobile-drawer a, .mobile-drawer-island a, .mobile-drawer a").forEach(link => {
      const href = link.getAttribute("href");
      if (!href) return;
      const cleanHref = href.replace(/\/$/, "").replace(/\.html$/, "");
      const cleanPath = currentPath.replace(/\.html$/, "");

      if (cleanHref === cleanPath || (cleanHref === "" && cleanPath === "/")) {
        link.classList.add("active");
      }
    });
  }

  // --- 3. Interactive Service Technical Specs Modal ---
  function initServiceModal() {
    const modal = document.getElementById("serviceModal");
    if (!modal) return;

    const closeBtn = modal.querySelector(".modal-close-btn");
    const modalEyebrow = document.getElementById("modalEyebrow");
    const modalTitle = document.getElementById("modalTitle");
    const modalOverview = document.getElementById("modalOverview");
    const modalSpecsList = document.getElementById("modalSpecsList");
    const modalDeliverablesList = document.getElementById("modalDeliverablesList");

    function closeModal() {
      modal.classList.remove("open");
      document.body.style.overflow = "";
    }

    if (closeBtn) {
      closeBtn.addEventListener("click", closeModal);
    }

    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal.classList.contains("open")) {
        closeModal();
      }
    });

    // Attach listeners to all spec-trigger buttons
    document.querySelectorAll("[data-service-trigger]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const serviceKey = btn.getAttribute("data-service-trigger");
        const data = servicesSpecs[serviceKey];
        if (!data) return;

        if (modalEyebrow) modalEyebrow.textContent = data.eyebrow;
        if (modalTitle) modalTitle.textContent = data.title;
        if (modalOverview) modalOverview.textContent = data.overview;

        if (modalSpecsList) {
          modalSpecsList.innerHTML = data.specs.map(s => `
            <div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--border-hairline); font-size: 13px;">
              <span style="font-weight: 600; color: var(--text-main); font-family: var(--font-heading);">${s.label}</span>
              <span style="font-family: var(--font-mono); color: var(--text-muted); text-align: right; margin-left: 12px;">${s.value}</span>
            </div>
          `).join("");
        }

        if (modalDeliverablesList) {
          modalDeliverablesList.innerHTML = data.deliverables.map(d => `
            <li style="display: flex; align-items: center; gap: 8px; font-size: 13px; color: var(--text-secondary); margin-bottom: 8px;">
              <span style="color: var(--emerald-nominal); font-weight: bold;">✓</span>
              <span>${d}</span>
            </li>
          `).join("");
        }

        modal.classList.add("open");
        document.body.style.overflow = "hidden";
      });
    });
  }

  // --- 4. RFQ Form & Direct WhatsApp Instant Connect ---
  function initRfqForm() {
    const form = document.getElementById("rfqForm");
    if (!form) return;

    form.addEventListener("submit", (e) => {
      e.preventDefault();

      const name = (form.querySelector('[name="name"]') || {}).value || "";
      const company = (form.querySelector('[name="company"]') || {}).value || "";
      const phone = (form.querySelector('[name="phone"]') || {}).value || "";
      const service = (form.querySelector('[name="service"]') || {}).value || "";
      const message = (form.querySelector('[name="message"]') || {}).value || "";

      // Real WhatsApp message format
      const waText = encodeURIComponent(
        `*PROFLIC TECHNOLOGIES — RFQ INQUIRY*\n` +
        `------------------------------------\n` +
        `• Name: ${name}\n` +
        `• Company: ${company}\n` +
        `• Phone: ${phone}\n` +
        `• Service: ${service}\n` +
        `• Details: ${message}\n` +
        `------------------------------------\n` +
        `Please review requirements and provide inspection quotation.`
      );

      // Real phone number: 918459706344
      const waUrl = `https://wa.me/918459706344?text=${waText}`;

      const feedback = document.getElementById("formFeedback");
      if (feedback) {
        feedback.innerHTML = `
          <div style="padding: 16px; border-radius: var(--radius-md); background: rgba(5, 150, 105, 0.08); border: 1px solid rgba(5, 150, 105, 0.2); color: var(--emerald-nominal); font-size: 13px; font-weight: 500; margin-top: 16px;">
            <p style="margin-bottom: 8px;"><strong>Inquiry Received!</strong> The PROFLIC engineering team will review your part specifications and revert quickly.</p>
            <a href="${waUrl}" target="_blank" rel="noopener" class="btn btn-primary btn-sm" style="margin-top: 6px; display: inline-flex;">
              Dispatch via WhatsApp (+91 84597 06344) →
            </a>
          </div>
        `;
      }

      form.reset();
    });
  }

  // --- 5. Animate Number Counters on Scroll ---
  function initCounters() {
    const counters = document.querySelectorAll(".counter-val");
    if (!counters.length) return;

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const target = parseFloat(el.getAttribute("data-target") || "0");
          const prefix = el.getAttribute("data-prefix") || "";
          const suffix = el.getAttribute("data-suffix") || "";
          const decimals = parseInt(el.getAttribute("data-decimals") || "0", 10);
          const duration = 1200;
          const startTime = performance.now();

          function update(now) {
            const elapsed = now - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const ease = 1 - Math.pow(1 - progress, 3);
            const current = target * ease;
            el.textContent = `${prefix}${current.toFixed(decimals)}${suffix}`;

            if (progress < 1) {
              requestAnimationFrame(update);
            } else {
              el.textContent = `${prefix}${target.toFixed(decimals)}${suffix}`;
            }
          }

          requestAnimationFrame(update);
          obs.unobserve(el);
        }
      });
    }, { threshold: 0.2 });

    counters.forEach(c => observer.observe(c));
  }

  // --- DOM Ready Bootstrapper ---
  document.addEventListener("DOMContentLoaded", () => {
    initHeader();
    initServiceModal();
    initRfqForm();
    initCounters();
  });

})();
